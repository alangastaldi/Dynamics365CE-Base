﻿using System;
using Microsoft.Xrm.Sdk;
using Common.Base.Helpers;

namespace $safeprojectname$ {
    public class $safeprojectname$ : PluginBase {
        public override void ExecutePlugin() {
            
        }
    }
}
